package RED

import RED.Funciones_Auxiliares

import java.io.{File, FileWriter, PrintWriter}
import scala.io.Source

object Main {

  val FA = new Funciones_Auxiliares

  def main(args: Array[String]): Unit = {
    val fileNameTraining = "../training_feature.csv"
    val fileNameTest = "../test_feature.csv"
    //val fileNameValidation = "C:/Users/jorge/Desktop/TFG/datos_covid/covid_validation.csv"
    val numRowsToKeep: Int = 3000 // Número de filas que deseas mantener

    var dataRows = Source.fromFile(fileNameTraining).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.take (numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    /*var dataRows = Source.fromFile(fileNameTraining).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }*/
    val dataListString: List[Array[String]] = dataRows.map(_.take(68))
    //val data: List[Array[Double]] = dataListString.map(_.map(_.toDouble))
    var valorString = dataRows.map(_(68))
    val valor: List[Double] = valorString.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    //dataRows.foreach(row => println(row.mkString(", ")))

    val filas = dataRows.length
    val columnas = if (filas > 0) dataRows.head.length else 0

    println(s"El número de filas es: $filas")
    println(s"El número de columnas es: $columnas")

    //Lo mismo para test
    var dataRowsTest = Source.fromFile(fileNameTest).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListStringTest: List[Array[String]] = dataRowsTest.map(_.take(68))
    //val dataTest: List[Array[Double]] = dataListStringTest.map(_.map(_.toDouble))
    var valorStringTest = dataRowsTest.map(_(68))
    val valorTest: List[Double] = valorStringTest.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    val data = dataListString.map(_.map(_.toDouble))
    val dataTest = dataListStringTest.map(_.map(_.toDouble))


    //número de características
    val nInputs: Int = data.headOption.map(_.length).getOrElse(0)
    //número de neuronas en la capa oculta
    val nHidden: Int =  (1.9*nInputs).toInt
    val I = 100
    val m = 100
    val pos_max = 1.0
    val c1 = 3.5
    val c2 = 1.8

    //val existingFile = new FileWriter(s"resultados_sonar_DAPSO_$iters _$parts _$v_max.txt", true)
    val existingFile = new FileWriter(s"resultados_fumador_$I _$m _$pos_max _$c1 _$c2.txt", true)
    val outputFile = new PrintWriter(existingFile)

    //Ejecución de PSO secuencial
    //val trainer = new pso_secuencial(data, valor, nInputs, nHidden, iters, parts, pos_max, c1, c2)

    //Ejecución de DAPSO
    val trainer = new DAPSO(data, valor, nInputs, nHidden, I, m, pos_max, c1, c2)
    trainer.inicializar_pesos()
    val start = System.nanoTime()
    trainer.procesar()
    val end = System.nanoTime()
    val weights = trainer.get_pesos()

    val duration = (end - start) / 1e9

    var predicha: List[Double] = List()
    for (i <- 0 until dataTest.length) {
      val prDouble = FA.forwardPropClas(dataTest(i), weights, nInputs, nHidden)
      val pr = FA.signo_umbral(prDouble, 0.5)
      predicha = predicha :+ pr
    }

    for ((real, predicho) <- valorTest.zip(predicha)) {
      //println(s"Real: $real - Predicho: $predicho")
      outputFile.println(s"$real,$predicho")
    }

    val unosReales = valorTest.count(_ == 1)
    val unosPredichos = predicha.count(_ == 1)

    println(s"La cantidad de unos reales es: $unosReales")
    println(s"La cantidad de unos predichos es: $unosPredichos")

    println("Resultados con pos_max: " + pos_max + ", c_1: " + c1 + ", c_2: " + c2 + ":")

    val error_out_test = FA.accuracyOfDataset(fileNameTest, weights, nInputs, nHidden, false, numRowsToKeep)
    val error_in = FA.accuracyOfDataset(fileNameTraining, weights, nInputs, nHidden, true, numRowsToKeep)

    println("Ein accuracy: " + error_in)
    println("Eout accuracy: " + error_out_test)

    outputFile.close()

    println(s"El programa tardó $duration segundos.")

  }
}
